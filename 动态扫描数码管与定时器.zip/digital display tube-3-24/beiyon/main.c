#include  "stm32f10x.h"
#include  "Delay.h"
#include "digital_tube.h"
int Control_Tube_Display(u8 num)
{
	if (num > 4)
			return -1;	
    switch (num) 
	{
		case 0:
			GPIO_WriteBit(GPIOE,GPIO_Pin_9, 1);
			GPIO_WriteBit(GPIOE,GPIO_Pin_10,0);
			GPIO_WriteBit(GPIOE,GPIO_Pin_11,0);
	  	GPIO_WriteBit(GPIOE,GPIO_Pin_12,0);
		break;
		case 1:
			GPIO_WriteBit(GPIOE,GPIO_Pin_9, 0);
			GPIO_WriteBit(GPIOE,GPIO_Pin_10,1);
			GPIO_WriteBit(GPIOE,GPIO_Pin_11,0);
	  	GPIO_WriteBit(GPIOE,GPIO_Pin_12,0);
		break;
		case 2:
			GPIO_WriteBit(GPIOE,GPIO_Pin_9, 0);
			GPIO_WriteBit(GPIOE,GPIO_Pin_10,0);
			GPIO_WriteBit(GPIOE,GPIO_Pin_11,1);
	  	GPIO_WriteBit(GPIOE,GPIO_Pin_12,0);
		break;
		case 3:
			GPIO_WriteBit(GPIOE,GPIO_Pin_9, 0);
			GPIO_WriteBit(GPIOE,GPIO_Pin_10,0);
			GPIO_WriteBit(GPIOE,GPIO_Pin_11,0);
	  	GPIO_WriteBit(GPIOE,GPIO_Pin_12,1);
		break;
	}
	return 0;
}	
void Init_74HC138_Pin(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
 
	//��ʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);
 
	//�������
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11| GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOE,&GPIO_InitStructure);
	
	GPIO_SetBits(GPIOE, GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11| GPIO_Pin_12);	
}
	

int main(void)
{
	int i = 0;
	Init_74HC138_Pin();
	Digital_Tube_Pin_Init();
	//Sys_Delay_Init();
	//Usart1_Pin_Init(115200);
	//printf("��ʼ���ɹ�\r\n");
	
	while(1)
	{
		for (i = 0; i < 4;i++) {
			Control_Tube_Display(i);
			Digital_Tube_Display(GPIOE,dynamic_code[i]);
			Delay_ms(2);
		}

}
		return 0;
}
