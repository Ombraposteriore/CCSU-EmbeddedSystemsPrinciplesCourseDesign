#include "stm32f10x.h" 
#ifndef __USART_H
#define __USART_H
             
#include "stdio.h"

#define USART_RX_LEN 200
#define USART1_RX_EN 1
extern uint8_t USART_RX_BUF[USART_RX_LEN];
extern uint16_t USART_RX_STA;
void uart_init(uint32_t bound);

#endif


