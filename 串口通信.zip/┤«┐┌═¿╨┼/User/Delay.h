#ifndef __DELAY_H
#define __DELAY_H

void Delay_us (int us);
void Delay_ms(int ms);
void Delay_s(int s);

#endif

