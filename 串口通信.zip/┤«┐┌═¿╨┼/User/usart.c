#include "stm32f10x.h"
#include "stm32f10x_usart.h"            // Keil::Device:StdPeriph Drivers:USART    
#include "usart.h"
#include "misc.h"                       // Keil::Device:StdPeriph Drivers:Framework
//#include "Key.h"
#include "interrupt.h"
#include "stdio.h"
#define USART_RX_LEN 200 // ���ջ�������С
#define USART_REC_LEN 100 // ���������ݳ���

#if SYSTEM_SUPPORT_OS
#include "includes.h"
#endif
#if 1
#pragma import(__use_no_semihosting)
struct __FILE{
	int handle;
};
FILE __stdout;
_sys_exit(int x){
	x=x;
}
int fputc(int ch, FILE *f){
	while((USART1->SR&0x40)==0);
	USART1->DR = (u8) ch;
	return ch;
}
#endif
#if USART1_RX_EN

uint8_t USART_RX_BUF[USART_RX_LEN];
uint16_t USART_RX_STA=0;




void uart_init(uint32_t bound){
	GPIO_InitTypeDef GPIO_InitStruct;
    USART_InitTypeDef USART_InitStruct;
    NVIC_InitTypeDef NVIC_InitStruct;

    // ʹ�� USART1 �� GPIO ʱ��
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE);

    // ���� USART1 �� TX ����Ϊ���ù���
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;

    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

    // ���� USART1 �� RX ����Ϊ���ù���
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10;
	  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStruct);
	
		//USART1 NVIC����
		NVIC_InitStruct.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 3;
    NVIC_InitStruct.NVIC_IRQChannelSubPriority = 3;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStruct);
		USART_InitStruct.USART_BaudRate = bound;
	
    // ���� USART1
    
    USART_InitStruct.USART_WordLength = USART_WordLength_8b;
    USART_InitStruct.USART_StopBits = USART_StopBits_1;
    USART_InitStruct.USART_Parity = USART_Parity_No;
    USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &USART_InitStruct);

    // ���� USART1 �ж�
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE); // ʹ�ܽ����ж�
    

    // ʹ�� USART1
    USART_Cmd(USART1, ENABLE);
}
void USART1_IRQHandler(void){
	uint8_t Res;
	#if SYSTEM_SUPPORT_OS
	OSIntEnter();
	#endif
	if(USART_GetITStatus(USART1,USART_IT_RXNE) != RESET){
		Res =USART_ReceiveData(USART1);
		if((USART_RX_STA&0x8000)==0){
			if(USART_RX_STA&0x4000){
				if(Res!=0x0a)USART_RX_STA=0;
				else USART_RX_STA|=0x8000;
			}
			else{
				if(Res==0x0d)USART_RX_STA|=0x4000;
				else{
					USART_RX_BUF[USART_RX_STA&0x3FFF]=Res;
					USART_RX_STA++;
					if(USART_RX_STA>(USART_REC_LEN-1))
						USART_RX_STA=0;
				}
			}
		}
	}
	#if SYSTEM_SUPPORT_OS
	OSIntExit();
	#endif
}
#endif
